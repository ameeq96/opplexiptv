<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="d-flex align-items-center gap-3">
        <button class="toggle-btn d-md-none" onclick="toggleSidebar()">
            <i class="bi bi-list"></i>
        </button>
        <h2 class="m-0">@yield('page_title', 'Dashboard')</h2>
    </div>
    <span class="d-none d-md-inline">Welcome, Admin</span>
</div>
