<div class="contact-message">
    <p>{{ __('messages.contact.intro') }}</p>
    <p>
        {{ __('messages.contact.whatsapp_info') }}: 
        <a href="https://wa.me/16393903194" target="_blank">
            +1 639-390-3194
        </a>
    </p>
    <p>{{ __('messages.contact.signature') }}</p>
</div>
